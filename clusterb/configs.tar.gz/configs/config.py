DB_NAME = "koredbm001"
COLLECTION_NAME_DATA = "btfaqs"
COLLECTION_NAME_STATUS = "btfaqsStatus"
COLLECTION_NAME_KT ="btknowledgetasks"
COLLECTION_NAME_ENTITY ="btentities"
COLLECTION_NAME_CLASSES ="btutteranceclasses"
COLLECTION_NAME_KG_STATUS = "btKgStatus"

MONGO_URI = "mongodb://kore:kore123@stack.korebot.svc:27017/?authSource=admin"
GREMLIN_SERVER_URL = "http://localhost:8182"
GREMLIN_SERVER_URL_LOCATION = ""
ML_SERVER_TRAIN_API = "http://clustere.korebot.svc:6006/ml/flying-train"
ML_SERVER_INTENT_API = "http://clustere.korebot.svc:6006/ml/flying-intent"
GRAPH_INPUT_PATH = "/data/faq-graph/BotGraph/"
JSON_OUTPUT_PATH = "/data/faq-graph/"
GREMLIN_JSON_INPUT_PATH = "/data/faq-graph/"


positiveClassBoundry=0.001
negativeClassBoundry=-0.5

RETRAIN_KNOWLEDGE_GRAPH = False
RETRAIN_OLD_FAQ = False



#keep FORKS = 0 utilizing all CPU cores
FORKS = 0
PORT = 5005
